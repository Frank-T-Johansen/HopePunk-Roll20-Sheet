# Ilya Novak — Mesh Hacker
**Optional handle:** Ghostline
**Concept:** Signal terrorist and AR illusionist with drone-feed instincts.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You do not just hack computers; you hack people’s senses.
**Home:** An old movie theater rigged as a personal VR den, filled with AI-crafted dreams.
## Ability
**See What I Want You to See** — Once per day, you can use the GhostWalk hack without having to roll for success.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Drone Warfare | 2 | Yes |
| Media | 1 | No |
| Big Guns | 1 | No |
| Hacking | 2 | Yes |

## Starting gear
**Clothes:** Haptic-coated bodysuit.
**Weapons:** Electro-dart launcher, Homemade flashbang.
**Equipment:** Illegal AR projector, Jailbroken Augs, Custom Cyberdeck.
**Credits:** 2000
**Debt/obligation:** Blacklisted from every mainstream mesh network.
