# Petra Vance — Scavenger
**Optional handle:** Rummage
**Concept:** Ruins-picker who survives by finding value in wreckage.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
Someone has to look for gold.
**Home:** A van filled to the brim with junk you have not found anyone to buy.
## Ability
**Oh, What’s This?** — Once per day you can happen upon a useful little gizmo, weapon, or piece of equipment worth below 300Cr from the Civilian Gear tables.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Evasion | 1 | No |
| Melee Combat | 1 | Yes |
| Stealth | 2 | No |
| Scavenging | 2 | Yes |

## Starting gear
**Clothes:** One high-end designer sneaker, One sandal, Dirty old cargo pants, Homemade cloak.
**Weapons:** Old revolver, Bent baseball bat.
**Equipment:** Out-of-tune Geiger counter, Old Aftermarket Augs, Duffle bag.
**Credits:** 1275
**Debt/obligation:** All fairly found laying around.
