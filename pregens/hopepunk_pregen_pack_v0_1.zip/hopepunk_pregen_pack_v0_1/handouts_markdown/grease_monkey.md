# Rosa Tan — Grease Monkey
**Optional handle:** Spanner
**Concept:** Machine whisperer with a toolbox full of stolen miracles.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You build machines. You fix machines. Sometimes, you punch machines.
**Home:** A corner of an old auto-shop, protected by booby-trapped junk piles.
## Ability
**Built Like a Tank** — As long as you are repairing something that belongs to you or an ally, you gain +2 to Jury-Rigging and Engineering.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Jury-Rigging | 2 | Yes |
| Cybernetics Handling | 1 | No |
| Piloting | 1 | Yes |
| Scavenging | 2 | No |

## Starting gear
**Clothes:** Grease-stained coveralls, Heavy-duty work boots.
**Weapons:** Power wrench, Old revolver.
**Equipment:** Toolbox full of borrowed corporate tech, Love letter from someone you ghosted, Mech-con Augs.
**Credits:** 800
**Debt/obligation:** 2,500 in unpaid garage fees.
