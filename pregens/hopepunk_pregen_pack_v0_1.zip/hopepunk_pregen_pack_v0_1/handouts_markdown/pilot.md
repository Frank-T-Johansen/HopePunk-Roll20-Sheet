# Talia Cruz — Pilot
**Optional handle:** Vector
**Concept:** Corporate-trained pilot who cannot stop answering the signal.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
Speed is king. Surviving it is queen.
**Home:** A tiny apartment in the Mega Building the corp you work for owns.
## Ability
**Get There Fast** — Once per Day, you can double the Movement speed of a Vehicle or Mech for one Round.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Drone Warfare | 1 | Yes |
| Cybernetics Handling | 1 | No |
| Engineering | 2 | No |
| Piloting | 2 | Yes |

## Starting gear
**Clothes:** Skintight haptic feedback suit.
**Weapons:** Compact holdout pistol.
**Equipment:** Full-connect hovercraft Augs, Piloting speedware, Cool aviator shades.
**Credits:** 30000
**Debt/obligation:** Licence renewal due in a week; flat 15,000Cr fee.
