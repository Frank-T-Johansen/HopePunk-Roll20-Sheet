# Lena Cross — Cat Burglar
**Optional handle:** Slip
**Concept:** Quiet thief who lives three exits ahead of the alarm.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
The only thing you want is other people's stuff.
**Home:** Someone else's apartment. You are not supposed to be staying there, and yet you still are.
## Ability
**Just Someone in the Crowd** — Once per day, as long as you are in or near a crowd, you can instantly lose any pursuit. Gain +2 to Stealth for the purposes of breaking and entering.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Stealth | 2 | Yes |
| Sabotage | 1 | No |
| Fast Talk | 1 | No |
| Infiltration | 2 | Yes |

## Starting gear
**Clothes:** Skintight catsuit underneath perfectly ordinary clothes.
**Weapons:** Switchblade tucked in your boot, Reliable old revolver.
**Equipment:** Climbing claws for scaling mega buildings, Black-market lockpicks, Jailbroken Augs.
**Credits:** 3000
**Debt/obligation:** Your fence owes you 5,000 still.
