# Jax Morrow — Gutter Rat Orphan
**Optional handle:** Scraps
**Concept:** Undercity survivor who knows where the city forgets to look.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You were not raised—you survived.
**Home:** A squat in an abandoned parking garage, surrounded by old shopping carts and makeshift tarps.
## Ability
**Rat Runs the Maze** — Once per day, you can find a secret, unmonitored path through the city: alleyways, sewer tunnels, maintenance shafts. Even in total lockdown, you always have an escape.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Melee Combat | 2 | Yes |
| Evasion | 1 | No |
| Street Cred | 1 | No |
| Parkour | 2 | Yes |

## Starting gear
**Clothes:** Mismatched urban wear, Ratty hoodie with corporate logos from five years ago.
**Weapons:** Rusted switchblade, Ancient semi-auto pistol.
**Equipment:** Lockpicks, Burner phone at 20% battery, Metro card with enough credits for one last ride, Aftermarket Augs.
**Credits:** 500
**Debt/obligation:** Owe 5,000 to a gang fixer.
