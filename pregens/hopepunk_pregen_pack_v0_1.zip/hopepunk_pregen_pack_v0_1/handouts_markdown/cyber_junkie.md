# Nika Voss — Cyber-Junkie
**Optional handle:** Glitch
**Concept:** Mesh addict and cortex-scorched systems savant.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You live more in the mesh than the real world.
**Home:** A VR cafe jury-rigged into a living space; half the customers think you are a digital ghost.
## Ability
**Overclocked Brain** — Once per day, you can either push your neural processor to triple speed, allowing you to use Hacking twice in a single action, or reroll a failed Hacking attempt.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Hacking | 2 | Yes |
| Awareness | 1 | Yes |
| Engineering | 1 | No |
| Cybernetics Handling | 2 | No |

## Starting gear
**Clothes:** LED-coated jacket that cycles through old hacker slogans, Programming socks.
**Weapons:** Compact electro-knife, Smart pistol with a safety override.
**Equipment:** Custom cyberdeck, Illegal firmware mod, Bottle of anti-seizure meds.
**Credits:** 500
**Debt/obligation:** 3,000 in debt to a hacker collective; they expect results.
