# Dana Kaur — Ex-Military
**Optional handle:** Sarge
**Concept:** Veteran deserter with battlefield instincts and old ghosts.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You have seen war. You do not want to see it again.
**Home:** A bunk in a shared mercenary dormitory, surrounded by other people running from something.
## Ability
**War Never Changes** — You never freeze in combat. If you are ambushed, you still get a turn before anything hits you.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Demolitions | 1 | No |
| Big Guns | 2 | Yes |
| First Aid | 2 | Yes |
| Sabotage | 1 | No |

## Starting gear
**Clothes:** Old combat fatigues, Dated armoured jacket stiff from dried blood.
**Weapons:** Heavily modified assault rifle, Knife with someone’s name scratched into the blade.
**Equipment:** Stolen military commlink, Expired rations, Crumpled photograph of old unit, Dated Mil-grade Augs, Armoured prosthetic limb.
**Credits:** 10500
**Debt/obligation:** No debt, but someone high up wants you erased.
