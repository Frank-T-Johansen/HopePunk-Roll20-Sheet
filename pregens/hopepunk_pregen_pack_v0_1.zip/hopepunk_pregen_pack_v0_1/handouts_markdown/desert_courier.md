# Salim Reyes — Desert Courier
**Optional handle:** Dust
**Concept:** Wasteland courier who treats speed as armour.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
Speed is survival. You never stay in one place for long.
**Home:** A converted cargo truck filled with old navigation maps and half-eaten protein bars.
## Ability
**Blink and You Miss Me** — Once per day, move twice as far in one Movement action, ignoring terrain penalties.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Piloting | 2 | Yes |
| Parkour | 2 | No |
| Stealth | 1 | Yes |
| Scavenging | 1 | No |

## Starting gear
**Clothes:** High-speed riding suit, Reinforced gloves.
**Weapons:** Compact submachine gun, Collapsible baton.
**Equipment:** Hacked GPS, Fake delivery credentials, Undelivered package, Aftermarket Augs.
**Credits:** 8000
**Debt/obligation:** Someone wants their package back.
