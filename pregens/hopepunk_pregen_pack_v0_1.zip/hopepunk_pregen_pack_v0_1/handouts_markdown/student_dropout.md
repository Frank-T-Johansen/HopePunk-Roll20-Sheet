# Noor Bellamy — Student Dropout
**Optional handle:** Late Fee
**Concept:** Corporate academy escapee with debts, passkeys, and questions.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
They said you had a bright future. Then you found out what the company was really doing.
**Home:** A clean corporate apartment still listed under an old identity; repo team is coming.
## Ability
**I Studied For This!** — Once per day, recall something you have studied, gaining +2 to any non-combat skill for a single roll.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Engineering | 2 | Yes |
| Xenobiology | 1 | No |
| Corporate | 2 | Yes |
| Persuasion | 1 | No |

## Starting gear
**Clothes:** Tailored corporate slacks, Cyber-optimal shades, School polo you forgot to return.
**Weapons:** Compact holdout pistol, Retractable stun baton.
**Equipment:** Personal encrypted datapad, Corporate passkey for older doors, Half-full bottle of overpriced synth-scotch, School-grade Brain-Interface Aug.
**Credits:** 2000
**Debt/obligation:** 100,000 in corporate debt; they want it back.
