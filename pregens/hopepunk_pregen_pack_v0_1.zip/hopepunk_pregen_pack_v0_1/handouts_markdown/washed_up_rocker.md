# Cass Vega — Washed Up Rocker
**Optional handle:** Static Cass
**Concept:** Former riot-maker with one song left and too many grudges.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You had a hit song once; now your royalty checks have dried up.
**Home:** A storage unit packed with old merch, a single mattress on the floor.
## Ability
**One Last Encore** — Once per day, as a Bonus Action, draw all attention, including enemy aggression, to yourself for one Round. All opponents in a combat scene within 30 Feet must roll a DC: 10 plus your Performance Save. On failure, they must include you in their next Attack Action.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Performance | 2 | Yes |
| Media | 1 | No |
| Fast Talk | 1 | Yes |
| Persuasion | 2 | No |

## Starting gear
**Clothes:** Aged leather jacket covered in tour patches, Ripped jeans.
**Weapons:** Microphone stand reinforced for fights, Switchblade.
**Equipment:** Broken holo-projector of your greatest performance, Signed poster of a rival you hate, Guitar case with a secret compartment, Musician Augs, Aural Cyberware.
**Credits:** 300
**Debt/obligation:** Owe a music label a whole album.
