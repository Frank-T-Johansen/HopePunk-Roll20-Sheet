# Elise Ward — Test Subject
**Optional handle:** Batch 7
**Concept:** Escaped experiment held together by faulty cyberware and stubbornness.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
Your body is not yours: it was an experiment.
**Home:** An underground shelter full of other lost souls, each one stranger than the last.
## Ability
**Glitch Mode** — Once per Combat, as a Free Action, activate Latent Experimental Cyberware. Roll a D4 for a one-turn effect: super speed, pain resistance, enhanced reflexes, or better vision. Afterward, lose 1D4 HP.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Jury-Rigging | 1 | No |
| First Aid | 2 | No |
| Cybernetics Handling | 1 | Yes |
| Survival | 2 | Yes |

## Starting gear
**Clothes:** Sterile hospital scrubs, Scavenged jacket.
**Weapons:** Serrated scalpel.
**Equipment:** Corporate barcode tattoo, Vial of mystery serum, Disposable mask.
**Credits:** 50
**Debt/obligation:** No explicit debt listed.
