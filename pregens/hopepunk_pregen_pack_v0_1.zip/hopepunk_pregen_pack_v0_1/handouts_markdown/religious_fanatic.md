# Jonah Mirek — Religious Fanatic
**Optional handle:** Witness
**Concept:** True believer whose faith keeps moving when sense says stop.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You believe in something bigger than yourself.
**Home:** A hidden underground chapel full of chanting believers.
## Ability
**Faith Drives Me** — Once per Combat, your faith keeps you going. Heal 1D4 HP as a Free Action.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Persuasion | 1 | Yes |
| Xenobiology | 1 | No |
| First Aid | 2 | No |
| Survival | 2 | Yes |

## Starting gear
**Clothes:** Hand-sewn priestly robes, Corporate combat boots.
**Weapons:** Blessed dagger, Shock-stick.
**Equipment:** Holy relic: reprogrammed AI core, Flask of sacred oil, probably combat drugs.
**Credits:** 500
**Debt/obligation:** Your cult expects absolute loyalty.
