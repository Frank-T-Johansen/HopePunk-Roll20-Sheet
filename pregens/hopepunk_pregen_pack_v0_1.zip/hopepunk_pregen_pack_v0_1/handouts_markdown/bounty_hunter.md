# Marcus Vale — Bounty Hunter
**Optional handle:** Tagger
**Concept:** Patient tracker and street-level contract hunter.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You track, trap, and terminate: whether for a payday or just the thrill.
**Home:** A crumbling safehouse in an abandoned police precinct, reinforced doors but no running water.
## Ability
**The Hunt Never Ends** — Once per day, declare a target. You gain +2 to all rolls that involve tracking, hunting, or hitting that one target in combat. The target does not need to be known to you; it can just be something you are hunting.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Investigation | 2 | Yes |
| Drone Warfare | 1 | No |
| Small Arms | 2 | Yes |
| Demolitions | 1 | No |

## Starting gear
**Clothes:** Long reinforced duster, Ballistic vest underneath.
**Weapons:** Custom revolver, Collapsible baton.
**Equipment:** Facial recognition scanner, Stun cuffs, Cigarette case filled with encrypted data chips.
**Credits:** 15000
**Debt/obligation:** Owe a bounty to the wrong people.
