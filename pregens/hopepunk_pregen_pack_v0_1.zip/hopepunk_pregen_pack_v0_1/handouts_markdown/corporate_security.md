# Adrian Holt — Corporate Security
**Concept:** Disgraced security professional with old protocols and new enemies.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You used to enforce the law. Now, you are above it.
**Home:** A safehouse in an old subway station; the last good cop still checks in on you.
## Ability
**Badge Intimidation** — Once per day, flash your old credentials and force someone to hesitate or comply, even if you have not been a cop in years. Gain +2 when trying to Bully any Civilian-type NPCs.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Investigation | 1 | No |
| Big Guns | 1 | No |
| Corporate | 2 | Yes |
| Small Arms | 2 | Yes |

## Starting gear
**Clothes:** Patched-up riot armour, Old department boots.
**Weapons:** Aged police-issue shotgun, Broken stun baton that still works sometimes.
**Equipment:** Department radio that stopped responding, Handcuffs, Bulletproof flask, Corp-grade Augs.
**Credits:** 5000
**Debt/obligation:** No explicit debt listed.
