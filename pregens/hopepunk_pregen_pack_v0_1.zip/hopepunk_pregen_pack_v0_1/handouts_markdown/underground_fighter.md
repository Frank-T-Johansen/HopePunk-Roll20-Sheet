# Tomasz Iversen — Underground Fighter
**Optional handle:** Brick
**Concept:** Pit-fighter who knows the sound a room makes before violence.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You survived the fight pits.
**Home:** A broken locker in the basement of a fight club, barely enough space to stretch out.
## Ability
**Knockout Blow** — Once per day, as a Free Action, you can attempt to Stun an enemy after making a successful Melee hit. The enemy rolls against DC 10 Save to avoid being Stunned for one turn.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Melee Combat | 2 | Yes |
| Blades | 2 | No |
| Bullying | 1 | No |
| Street Cred | 1 | Yes |

## Starting gear
**Clothes:** Bloodstained tank top, Fingerless gloves.
**Weapons:** Titanium-plated knuckledusters, Combat knife.
**Equipment:** Betting slips from old fights, Augmented scanner, Adrenaline Stim.
**Credits:** 10000
**Debt/obligation:** On the hit list of an underground fight promoter.
