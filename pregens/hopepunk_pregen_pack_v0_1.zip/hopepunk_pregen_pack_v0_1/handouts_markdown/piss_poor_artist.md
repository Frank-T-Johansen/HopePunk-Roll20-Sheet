# Emi Laurent — Piss-Poor Artist
**Optional handle:** Smudge
**Concept:** Broke street artist who sees the city as unfinished canvas.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
Maybe one day people will recognize you? Probably not.
**Home:** A run-down cubicle apartment in a rent-a-day centre; they forgot to charge you last week.
## Ability
**The Muse Smiles** — Once per Day, gain a sudden burst of inspiration, allowing you to gain Advantage (1D4 + your Performance) on a single Non-Combat roll.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Fast Talk | 1 | Yes |
| Performance | 2 | Yes |
| Media | 2 | No |
| Jury-Rigging | 1 | No |

## Starting gear
**Clothes:** Baggy jeans, Loose sweater covered in paint stains.
**Weapons:** Switchblade found on the streets.
**Equipment:** Jailbroken Augs, Nine pirated Abode products.
**Credits:** 0
**Debt/obligation:** About 40,000 in Art School loans with 22% compounding interest.
