# Milo Rask — Gambler on the Run
**Optional handle:** Lucky
**Concept:** Charming runaway whose luck has a body count.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You bet it all; now you gamble that you can outrun your problems.
**Home:** A roach-infested motel room on the outskirts, paid in cash under a fake name.
## Ability
**Lady Luck** — Once per day, if you roll a 20 on a D20, replace the result with a 2. Once per day, if you have sacrificed a 20 result, you may replace any other result with a Critical Success.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Persuasion | 1 | No |
| Small Arms | 2 | Yes |
| Underworld | 1 | No |
| Fast Talk | 2 | Yes |

## Starting gear
**Clothes:** Long jacket with gang patches hastily removed, Cargo pants, Very snazzy hat.
**Weapons:** Sawed-off shotgun, Rusted trench knife.
**Equipment:** Hidden gang tattoo, Fake identity chip, Lucky coin stolen from the wrong person, Jailbroken Augs.
**Credits:** 100
**Debt/obligation:** 5,000 credits in blood money debt.
