# Kenji Park — Samurai Otaku
**Concept:** Obsessive Samurai fan with merch, footwork, and no field time.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
Your Oshi is the best! You are going to be just like them.
**Home:** The basement at your mother’s place.
## Ability
**Say hello to my little (fake) friend!** — You have a collection of high-end, hyper-realistic recreations of popular Samurai gear. All of it is non-functional. Once per day, you can produce a fake version of a Tier-three piece of equipment.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| Performance | 2 | Yes |
| Media | 1 | No |
| Fast Talk | 1 | No |
| Street Cred | 2 | Yes |

## Starting gear
**Clothes:** Jacket with your favourite Samurai on the back, Ratty band shirt.
**Weapons:** Officially branded katana.
**Equipment:** Body pillow of your favourite Samurai, Music sticks, Corp-grade Augs.
**Credits:** 10000
**Debt/obligation:** A lot of collectibles.
