# Dr. Mira Sayegh — Rogue Surgeon
**Optional handle:** Needle
**Concept:** Black-clinic surgeon who can patch almost anything except trust.
**Civilian status:** Not yet Samurai.
**Customization note:** Ready to play. Rename freely before play. This character is not yet Samurai unless the GM starts after the upgrade event. You may swap proficiencies among Background skills and may move the two starting Skill Points before play.
## Background
You fix people. Sometimes. You try, at least.
**Home:** An abandoned ambulance, still stocked with supplies. The siren still works.
## Ability
**Meat is Weak** — Once per Combat as a Bonus Action, you can patch up yourself or an Ally. Roll a DC: 10 First Aid check; on a success, you or your ally heals for 1D6.
## Skills
| Skill | Level | Proficient |
|---|---:|---|
| First Aid | 2 | Yes |
| Cybernetics Handling | 2 | Yes |
| Persuasion | 1 | No |
| Investigation | 1 | No |

## Starting gear
**Clothes:** Bloodstained surgical scrubs, Reinforced apron.
**Weapons:** Bone saw, Syringe gun filled with mystery anesthetic.
**Equipment:** Mobile surgery kit, Box of untested cybernetic augments, Flask of medicinal whiskey.
**Credits:** 20000
**Debt/obligation:** Wanted for illegal body mods.
